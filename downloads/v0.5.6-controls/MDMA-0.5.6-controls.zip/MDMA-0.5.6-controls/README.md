# MDMA for M-VAVE FM-1

Performance firmware with six layers, four scenes per city and a 16-step drum sequencer. **0.5.6-controls** is the official release and the starting point for development.

**[Download the firmware ZIP](https://github.com/mdmarinato/MDMA/raw/refs/heads/main/downloads/v0.5.6-controls/MDMA-0.5.6-controls.zip)**

Extract the ZIP and use `mdma-0.5.6-controls.fwsc` for the FM-1.

[Controls guide](https://github.com/mdmarinato/MDMA/blob/main/docs/controls.md) · [Build and test](https://github.com/mdmarinato/MDMA/blob/main/docs/build.md) · [Release notes](https://github.com/mdmarinato/MDMA/releases/tag/v0.5.6-controls)

The package includes the firmware, the incremental controls patch and its host test. To verify the extracted files, run `sha256sum -c SHA256SUMS` in this folder.
