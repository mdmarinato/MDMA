# Revisão de controles para MDMA 0.5.6-alpha

O arquivo .fwsc é a compilação para FM-1. O patch é incremental sobre as fontes Dinghy da tag v0.5.6-alpha. Para reproduzir, siga os passos daquela versão, aplique também controls.patch e compile com --release 0.5.6-controls.

A última tecla preta corta e recupera as camadas que estavam ativas. SEQ programa o fill. Em EDIT, OCT− e OCT+ navegam entre camadas e as teclas de camada alternam seu áudio. O LEAD usa GRID, inclusive ao carregar uma cidade antiga. O código de síntese FREE está preservado.

SAVE oferece SAVE TO DEVICE, POINT e DELETE POINT. O reset está em GLO. No mapa e no mixer, a camada selecionada fica no alto à esquerda. SOLO e MUTE usam a posição do aviso de fill. MIX e FX percorrem de três a dez unidades por clique conforme a velocidade. O ganho de EQ mantém a resolução anterior.
