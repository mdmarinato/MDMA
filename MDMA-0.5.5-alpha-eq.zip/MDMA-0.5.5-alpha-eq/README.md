# MDMA 0.5.5-alpha-eq para FM-1

O firmware instalável está em `build/MDMA-0.5.5-alpha-eq.fwsc`. Na lista, no mapa e no mixer, FX percorre MIX, FX e EQ. HOME muda a tela e conserva o modo dos knobs. SELECT escolhe a camada. O banco EQ controla LO, LO-MID, HI-MID e HI, de −9 a +6 dB em passos de 1 dB. O centro musical é 0 dB. O mixer das camadas trabalha a 11.025 Hz, com divisões aproximadas de 150, 680 e 2.430 Hz. A banda HI da bateria também controla o componente seco de alta frequência a 44,1 kHz.

EDIT abre os parâmetros e outro toque volta à HOME. SAVE identifica área ocupada, erro de leitura e pontos com cópia recuperável. Nas duas linhas finais de SAVE, ALGORITHM escolhe um ponto ou cidade, ou o conjunto. OCT+ abre a confirmação e OCT+ confirma. OCT− cancela. DELETE POINTS pula pontos protegidos. RESET CITY restaura os parâmetros e padrões da receita, mantém as cidades geradas e grava o conjunto atual no save principal. Os pontos continuam separados. Antes de voltar para uma versão anterior, exporte um backup. Saves com EQ editado usam uma extensão do registro MGR6.

## Reproduzir

Use o Dinghy `ea1b6bf5973b11f9b4b806d08155602aaa0b505e`, o compilador JieLi Linux 20260730.1 e os arquivos do SDK AC79NN `d179b4484759423312073f5fbb232501aa491047`. O espelho do compilador é a release `toolchain-20260730.1` de `DimmKirr/setup-fm1-toolchain` no GitHub. O SHA-256 do tar.xz reempacotado é `d3fc3be92cfc07ccb0ac682b3b2e41e4d14593426067e6c3c6e908db2f90c0e0`.

No Dinghy, com PKG apontando para este pacote extraído:

```sh
git apply "$PKG/firmware/MDMA-0.5.5-alpha-live.patch"
git apply "$PKG/firmware/alpha-eq.patch"
node tools/mdma_patterns.cjs "$PKG/reference/stable-v0.5.html"
python3 tools/mdma_lead_tables.py
python3 tools/mdma_mix_tables.py
JIELI_TOOLCHAIN=/caminho/toolchain AC79_SDK=/caminho/sdk ./build.sh --release 0.5.5-alpha-eq
cmp build/mdma-0.5.5-alpha-eq.fwsc "$PKG/build/MDMA-0.5.5-alpha-eq.fwsc"
sh "$PKG/tests/run-all.sh" /caminho/fm1-emu/web/dist
```

Verificado em host e no fm1-emu upstream v0.5.1 a 100 MHz com LCD temporizado. Com EQ nas seis camadas, o maior pico nas nove janelas de quatro segundos foi 5.547 µs para um prazo de 5.805 µs. Avaliação no FM-1 físico pendente.
